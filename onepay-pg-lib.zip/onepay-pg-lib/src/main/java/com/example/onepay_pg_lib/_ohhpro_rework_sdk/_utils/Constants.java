package com.example.onepay_pg_lib._ohhpro_rework_sdk._utils;

public class Constants {
    public static final String merchantID = "M00003462349643";
    public static final String secretKey = "zh6Um5di9jmdfsdfs39fb6QX7Z34343W6pq1sdWsd22W8Mk4232yh";
    public static final String iv = "fj0RH235hmsd2Elasd7FV8yad2323sada";
    public static final String ALGORITHM = "AES/CBC/PKCS5Padding";
    public static final String PAYMENT_GATEWAY_URL_dev = "https://pa-preprod.1pay.in/payment/payprocessorV2";

    public static final String PAYMENT_GATEWAY_URL_prod = "https://pay.1pay.in/payment/payprocessorV2";


    // public static final String PAYMENT_GATEWAY_RET_URL = "https://pa-preprod.1pay.in/payment/merchantResponse.jsp";  //change checkURL function in webV if this is change
    //public static final String PAYMENT_GATEWAY_RET_URL = "https://expressrates.in/response_json.php";
    // public static final String PAYMENT_GATEWAY_RET_URL = "https://florix.net/1Pay_php/response.php";
    public static final String PAYMENT_GATEWAY_RET_URL = "http://yourdomain.com/";
    //public static final String PAYMENT_GATEWAY_RET_URL = "https://lance23074.pythonanywhere.com/loader";
    public static final String PAYMENT_GATEWAY_RES_URL = "https://pa-preprod.1pay.in/payment/getTxnDetails";
}
