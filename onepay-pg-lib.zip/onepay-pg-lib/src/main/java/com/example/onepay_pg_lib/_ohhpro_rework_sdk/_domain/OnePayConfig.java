package com.example.onepay_pg_lib._ohhpro_rework_sdk._domain;

import com.example.onepay_pg_lib._ohhpro_rework_sdk._presentation.OnePayPaymentStatus;

 public class OnePayConfig {
    public static OnePayPaymentStatus paymentStatusListener = null;
}
