package com.example.onepay_pg_lib._ohhpro_rework_sdk._data;

public class PaymentRequest {
    private final String merchantId;
    private final String transactionId;
    private final String jsonPayload;

    private final boolean isDev;

    public boolean isDevelopment() {
        return isDev;
    }

    public PaymentRequest(String merchantId, String transactionId, String jsonPayload, boolean isDevelopment) {
        this.merchantId = merchantId;
        this.transactionId = transactionId;
        this.jsonPayload = jsonPayload;
        this.isDev = isDevelopment;
    }

    // Getters
    public String getMerchantId() { return merchantId; }
    public String getTransactionId() { return transactionId; }
    public String getJsonPayload() { return jsonPayload; }

}
