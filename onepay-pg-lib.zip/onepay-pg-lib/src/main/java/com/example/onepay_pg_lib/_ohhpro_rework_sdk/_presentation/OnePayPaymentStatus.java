package com.example.onepay_pg_lib._ohhpro_rework_sdk._presentation;

import com.example.onepay_pg_lib._ohhpro_rework_sdk._data.PaymentResponse;

public interface OnePayPaymentStatus {
    void onePayPayment_Success(PaymentResponse response);
    void onePayPayment_Failed(PaymentResponse response);
    void onePayPayment_TimeOut(PaymentResponse response);
    void onePayPayment_Pending(PaymentResponse response);
}


