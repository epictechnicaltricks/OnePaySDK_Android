package com.example.onepay_pg_lib._ohhpro_rework_sdk._domain;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;

import androidx.fragment.app.Fragment;

import com.example.onepay_pg_lib._ohhpro_rework_sdk._presentation.PaymentOnePayActivity;
import com.example.onepay_pg_lib._ohhpro_rework_sdk._presentation.OnePayPaymentStatus;
import com.example.onepay_pg_lib._ohhpro_rework_sdk._data.PaymentRequest;

public class OnePayCheckout {

    public void startPayment(PaymentRequest data, Object caller) {
        Context context = null;
        OnePayPaymentStatus listener = null;

        if (caller instanceof Fragment) {
            Fragment fragment = (Fragment) caller;
            context = fragment.getContext();
            if (fragment instanceof OnePayPaymentStatus) {
                listener = (OnePayPaymentStatus) fragment;
            }
        } else if (caller instanceof Activity) {
            context = (Activity) caller;
            if (caller instanceof OnePayPaymentStatus) {
                listener = (OnePayPaymentStatus) caller;
            }
        }

        if (context == null || listener == null) {
            throw new IllegalArgumentException("Caller must be an Activity or Fragment that implements OnePayPaymentStatus");
        }

        OnePayConfig.paymentStatusListener = listener;

        Intent intent = new Intent(context, PaymentOnePayActivity.class);
        intent.putExtra("jsonString", data.getJsonPayload());
        intent.putExtra("merchantId", data.getMerchantId());
        intent.putExtra("transactionId", data.getTransactionId());
        intent.putExtra("isDev", data.isDevelopment());

        context.startActivity(intent);
    }

}
