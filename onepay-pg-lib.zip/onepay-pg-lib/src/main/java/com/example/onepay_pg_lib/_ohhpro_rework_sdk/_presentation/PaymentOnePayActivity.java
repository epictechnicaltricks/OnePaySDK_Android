package com.example.onepay_pg_lib._ohhpro_rework_sdk._presentation;

import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.example.onepay_pg_lib.BuildConfig;
import com.example.onepay_pg_lib.R;
import com.example.onepay_pg_lib._ohhpro_rework_sdk._data.PaymentResponse;
import com.example.onepay_pg_lib._ohhpro_rework_sdk._data.PaymentStatus;
import com.example.onepay_pg_lib._ohhpro_rework_sdk._domain.OnePayConfig;
import com.example.onepay_pg_lib._ohhpro_rework_sdk._utils.Constants;

import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;

public class PaymentOnePayActivity extends AppCompatActivity {

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_payment_onepay);
        WebView webViewPay = findViewById(R.id.webView875675464r);

        getOnBackPressedDispatcher().addCallback(new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                if(webViewPay.canGoBack()) {
                    new AlertDialog.Builder(PaymentOnePayActivity.this)
                            .setTitle("Want to Go back?")
                            .setMessage("\n\n")
                            .setPositiveButton("Yes, Back", (dialog, which) -> {
                                webViewPay.goBack();
                            })
                            .setNegativeButton("No", (dialog, which) -> {
                            })
                            .create()
                            .show();

                } else  {
                    new AlertDialog.Builder(PaymentOnePayActivity.this)
                            .setTitle("Cancel Payment?")
                            .setMessage("\n\n")
                            .setPositiveButton("Yes, Cancel", (dialog, which) -> {
                                notifyResult(PaymentStatus.FAILED);
                                finish();
                            })
                            .setNegativeButton("No", (dialog, which) -> {
                            })
                            .create()
                            .show();
                }
            }
        });

        webViewPay.setOnLongClickListener(v -> false);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        String jsonString = getIntent().getStringExtra("jsonString");
        String merchantId = getIntent().getStringExtra("merchantId");
        String transactionId = getIntent().getStringExtra("transactionId");

        WebSettings webSettings = webViewPay.getSettings();
        webSettings.setJavaScriptEnabled(true);


        webViewPay.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);

                if(BuildConfig.DEBUG) {
                    Log.d("234dsf343", "onPageFinished >> ");
                }

                view.evaluateJavascript(
                        "(function() { return document.body.innerText; })();",
                        value -> {
                            if (value == null) return;

                            // Clean quotes around the value (because value is a JSON string)
                            value = value.replaceAll("^\"|\"$", "").replace("\\n", "\n").replace("\\\"", "\"");

                            if(BuildConfig.DEBUG) {
                                Log.d("234dsf343", "onPageFinished value >> " + value);
                            }

                            if (value.contains(PaymentStatus.SUCCESS.getMessage())) {
                                notifyResult(PaymentStatus.SUCCESS);
                            } else if (value.contains(PaymentStatus.FAILED.getMessage())) {
                                notifyResult(PaymentStatus.FAILED);
                            } else if (value.contains(PaymentStatus.PENDING.getMessage())) {
                                notifyResult(PaymentStatus.PENDING);
                            } else if (value.contains(PaymentStatus.TIMEOUT.getMessage())) {
                                notifyResult(PaymentStatus.TIMEOUT);
                            }
                        }
                );



            }
        });


        try {
            if (jsonString != null) {

                String url = getIntent().getBooleanExtra("isDev", false)
                        ? Constants.PAYMENT_GATEWAY_URL_dev
                        : Constants.PAYMENT_GATEWAY_URL_prod;

                String postData = "reqData=" + URLEncoder.encode(jsonString, "UTF-8") +
                            "&merchantId=" + URLEncoder.encode(merchantId, "UTF-8");


                webViewPay.postUrl(url, postData.getBytes(StandardCharsets.UTF_8));


                if(BuildConfig.DEBUG)
                {
                    Log.d("234dsf343", merchantId);
                    Log.d("234dsf343", transactionId);
                    Log.d("234dsf343", jsonString);
                    Log.d("234dsf343", url);
                }




            } else  {
                Toast.makeText(this, "ReqData not available! or null", Toast.LENGTH_SHORT).show();
                finish();
            }
        } catch (Exception e) {
            e.printStackTrace();
            finish();
        }
    }


    private void notifyResult(PaymentStatus status) {
        if (OnePayConfig.paymentStatusListener != null) {
            PaymentResponse response = new PaymentResponse(
                    status.name(),
                    status.getMessage(),
                    getIntent().getStringExtra("transactionId")
            );

            switch (status) {
                case SUCCESS: {
                    OnePayConfig.paymentStatusListener.onePayPayment_Success(response);
                    break;
                }

                case FAILED: {
                    OnePayConfig.paymentStatusListener.onePayPayment_Failed(response);
                    break;
                }

                case PENDING: {
                    OnePayConfig.paymentStatusListener.onePayPayment_Pending(response);
                    break;
                }

                case TIMEOUT: {
                    OnePayConfig.paymentStatusListener.onePayPayment_TimeOut(response);
                }

            }

            OnePayConfig.paymentStatusListener = null;
        }

        finish();
    }


}