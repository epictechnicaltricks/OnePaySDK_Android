package com.example.onepay_pg_lib._ohhpro_rework_sdk._data;

public enum PaymentStatus {

    SUCCESS("Payment Successful!"),
    FAILED("Payment Failed"),
    TIMEOUT("Transaction Timed Out"),
    PENDING("Payment Pending");

    private final String message;

    public String getMessage() {
        return message;
    }

    PaymentStatus(String message){
        this.message = message;
    }

}
