package com.example.onepay_pg_lib._ohhpro_rework_sdk._data;

public class PaymentResponse {
    private final String status;
    private final String message;
    private final String transactionId;

    public PaymentResponse(String status, String message, String transactionId) {
        this.status = status;
        this.message = message;
        this.transactionId = transactionId;
    }

    // Getters
    public String getStatus() { return status; }
    public String getMessage() { return message; }
    public String getTransactionId() { return transactionId; }
}
